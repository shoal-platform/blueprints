document.querySelector('#app').innerHTML = `
  <h1>Hello World</h1>
  <p id="status">I'm alive</p>
`
